﻿using System;
namespace Minedraft.Core.Commands
{
    public class RegisterCommand : Command
    {
        public override string Execute()
        {
            throw new NotImplementedException();
        }
    }
}
